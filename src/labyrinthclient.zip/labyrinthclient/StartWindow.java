
package labyrinthclient;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class StartWindow {

        private JFrame frame;
        private JPanel panel;
        
        public StartWindow(){
                frame = new JFrame();
                
                Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
                frame.setBounds(d.width/2 - 200, d.height/2 - 150, 300, 150);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                panel = new JPanel();
                panel.setLayout(null);
                panel.setBackground(Color.black);
                frame.add(panel);
                
                JTextField IPTextField = new JTextField("localhost");
                IPTextField.setBounds(20, 20, 150, 30);
                panel.add(IPTextField);
                
                JTextField portTextField = new JTextField("666");
                portTextField.setBounds(20, 60, 150, 30);
                panel.add(portTextField);
                
                JButton connectButton = new JButton("Connect!");
                connectButton.setBounds(180, 20, 90, 70);
                connectButton.addActionListener((ActionEvent e) -> {
                        connect(IPTextField.getText(), Integer.parseInt(portTextField.getText()));
                });
                panel.add(connectButton);
                frame.setVisible(true);
        }
        
        private void connect(String ip, int port){
                try {
                        new Player(ip, port);
                        frame.dispose();
                } catch (Exception e) {
                }
        }
        
        public static void main(String[] args){
                new StartWindow();
        }
}
