
package labyrinthclient;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUI{
  
        private JFrame frame;
        private Graphics g;
        private final int width, height, labyrinthWidth, labyrinthHeight, squareSize;
        private final String playerName;
        private final Color playerColor;
        private final Point startPosition;
        private String[] splitInformation;

        public GUI(String allInformation, Player player){
                Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
                this.splitInformation = allInformation.split(":");
                this.playerName = splitInformation[1];
                this.playerColor = new Color(Integer.parseInt(splitInformation[2]));
                this.startPosition = new Point(Integer.parseInt(splitInformation[3]),Integer.parseInt(splitInformation[4]));
                this.labyrinthWidth = Integer.parseInt(splitInformation[5]);
                this.labyrinthHeight = Integer.parseInt(splitInformation[6]);
                
                if(d.width / labyrinthWidth < d.height / labyrinthHeight){
                        int help = d.width * 9 / 10;
                        squareSize = help / labyrinthWidth;
                }else{
                        int help = d.height * 9 / 10;
                        squareSize = help / labyrinthHeight;
                }
                width = labyrinthWidth * squareSize;
                height = labyrinthHeight * squareSize;
                
                frame = new JFrame();
                
                frame.setBounds(d.width/2 - width/2, d.height/2 - height/2, width + 1, height + 1);
                frame.setUndecorated(true);
                frame.setVisible(true);
                frame.addKeyListener(player);
                g = frame.getGraphics();
                g.setFont(new Font("Arial", Font.BOLD, 30));
        }

        public void drawMaze(){
                g.setColor(Color.black);
                g.fillRect(0, 0, width, height);
                g.setColor(Color.white);
                for(int i = 7 ; i < splitInformation.length ; i++){
                        String[] wall = splitInformation[i].split(",");
                        int x1 = Integer.parseInt(wall[0]);
                        int y1 = Integer.parseInt(wall[1]);
                        int x2 = Integer.parseInt(wall[2]);
                        int y2 = Integer.parseInt(wall[3]);
                        g.drawLine(x1 * squareSize, y1 * squareSize, x2 * squareSize, y2 * squareSize);
                }
                g.setColor(Color.green);
                g.fillRect(labyrinthWidth/2 * squareSize + 1, labyrinthHeight/2 * squareSize + 1, squareSize - 1, squareSize - 1);
                
                g.setColor(Color.yellow);
                g.fillOval(squareSize + squareSize/4, squareSize/4, squareSize/2, squareSize/2);
        }
        
        public void waitScreen(){
                g.setColor(Color.black);
                g.fillRect(0, 0, width, height);
                
                g.setColor(playerColor);
                g.fillRect(startPosition.x * squareSize, startPosition.y * squareSize, squareSize, squareSize);
                
                g.setColor(Color.white);
                g.drawString("Du bist " + playerName, width/2 - 100, height/2 - 100);
                g.drawString("Warten auf Spieler...", width/2 - 150, height/2);
        }
        
        public void startScreen(){
                
                g.setColor(Color.black);
                g.fillRect(width/2 - 150, height/2 - 50, 400, 100);
                
                g.setColor(Color.white);
                g.drawString("Es fängt an!", width/2 - 100, height/2);
        }
        
        public void countdown(String info){
                g.setColor(Color.black);
                g.fillRect(width/2 - 50, height/2 + 30, 200, 100);
                
                if(info.split(",")[1].equals("0")){
                        drawMaze();
                }else{
                        g.setColor(Color.white);
                        g.drawString(info.split(",")[1], width/2 , height/2 + 80);
                }
        }
        
        public void playerWon(String info){
                g.setColor(Color.black);
                g.fillRect(0, 0, width, height);
                String player = info.split(",")[1];
                g.setColor(Color.white);
                g.drawString(player + " hat gewonnen!!", width/2 - 150, height/2);
        }
        
        public void updatePlayerPosition(String information){
                String[] splitInformation = information.split(",");
                int x1 = Integer.parseInt(splitInformation[1]);
                int y1 = Integer.parseInt(splitInformation[2]);
                g.setColor(Color.black);
                g.fillRect(x1 * squareSize + 1, y1 * squareSize + 1, squareSize - 1, squareSize - 1);
                int colorRGB = Integer.parseInt(splitInformation[3]);
                g.setColor(new Color(colorRGB));
                int x2 = Integer.parseInt(splitInformation[4]);
                int y2 = Integer.parseInt(splitInformation[5]);
                g.fillRect(x2 * squareSize + 1, y2 * squareSize + 1, squareSize -1, squareSize - 1);
        }
        
        public void close(){
                frame.dispose();
        }
        
}
