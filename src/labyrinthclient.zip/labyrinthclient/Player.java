
package labyrinthclient;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Player implements KeyListener{
  
        private BufferedReader read = null;
        private PrintWriter write = null;
        private boolean alive = true;
        private GUI gui;

        public Player(String ip, int port) {
                try {
                        Socket socket = new Socket(ip, port);
                        read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        write = new PrintWriter(socket.getOutputStream());
                        listen();
                }catch (Exception e) {
                }
        }

        public void send(String buffer) {
                try {
                        write.write(buffer + "\n");
                        write.flush();
                } catch (Exception e) {
                }
        }

        public void kill(){
                alive = false;
        }
        
        private void listen() {
                new Thread(() ->{
                        try {
                                while (alive) {
                                        String info = read.readLine();
                                        switch(info.charAt(0)){
                                                case 'm':this.updatePlayerPosition(info);
                                                break;
                                                case 'l':this.setupGUI(info);
                                                break;
                                                case 'w':this.playerWon(info);
                                                break;
                                                case 's':this.gameStarting();
                                                break;
                                                case 'c':this.countdown(info);
                                                break;
                                                default:
                                                break;
                                        }
                                }
                        } catch (Exception e) {
                                System.out.println("Disconnected!");
                        }
                }).start();
                
        }
        
        public void setupGUI(String allInformation){
                if(this.gui != null){
                        this.gui.close();
                }
                this.gui = new GUI(allInformation, this);
                try {
                        Thread.sleep(100);
                } catch (InterruptedException ex) {
                }
                this.gui.waitScreen();
        }
        
        public void playerWon(String info){
                this.gui.playerWon(info);
        }
        
        public void gameStarting(){
                this.gui.startScreen();
        }
        
        public void countdown(String info){
                this.gui.countdown(info);
        }
        
        public void updatePlayerPosition(String information){
                this.gui.updatePlayerPosition(information);
        }
  
        @Override
        public void keyTyped(KeyEvent e) {
                
        }

        @Override
        public void keyPressed(KeyEvent e) {
                switch(e.getKeyCode()){
                        case KeyEvent.VK_A: send("left");
                        break;
                        case KeyEvent.VK_LEFT: send("left");
                        break;
                        case KeyEvent.VK_S: send("down");
                        break;
                        case KeyEvent.VK_DOWN: send("down");
                        break;
                        case KeyEvent.VK_D: send("right");
                        break;
                        case KeyEvent.VK_RIGHT: send("right");
                        break;
                        case KeyEvent.VK_W: send("up");
                        break;
                        case KeyEvent.VK_UP: send("up");
                        break;
                        case KeyEvent.VK_X:
                                kill();
                                send("x");
                                this.gui.close();
                        break;
                }
        }

        @Override
        public void keyReleased(KeyEvent e) {
                
        }
}